import React from "react";
import QuestsNavBar from "../components/QuestsNavBar";

const QuestslandingPage = () => {
  return (
    <>
      <QuestsNavBar />
    </>
  );
};

export default QuestslandingPage;
