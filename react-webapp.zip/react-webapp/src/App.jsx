import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import ContactUs from "./pages/ContactUs";
import LogInPage from "./pages/LogInPage";
import QuestsLandingPage from "./pages/QuestsLandingPage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="contact" element={<ContactUs />} />
          <Route path="login" element={<LogInPage />} />
          <Route path="questslandingpage" element={<QuestsLandingPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
