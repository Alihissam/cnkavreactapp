import arrowIcon from "./assets/icons/arrow.png";
import avatarGroup from "./assets/icons/avatar-group.png";
import appleLogo from "./assets/icons/apple.png";
import checkImage from "./assets/icons/check.png";
import cnkavLogo from "./assets/icons/cnkav-logo.png";
import crowdImage from "./assets/images/crowd.jpg";
import drinkMan from "./assets/images/drink.jpg";
import dropDownIcon from "./assets/icons/drop.png";
import fiverStars from "./assets/icons/five-stars.png";
import facebookLogo from "./assets/icons/facebook.png";
import galleryImage from "./assets/images/gallery.png";
import gentalMan from "./assets/images/gentalman.jpg";
import greenCheck from "./assets/icons/green-check.png";
import googleLogo from "./assets/icons/google.png";
import helloHand from "./assets/icons/hello-hand.png";
import linkedinImage from "./assets/icons/linkedin.png";
import modalMan from "./assets/images/modalman.png";
import monyImage from "./assets/images/mony.png";
import nextIcons from "./assets/icons/next.png";
import questImage from "./assets/images/quest.png";
import rollsImage from "./assets/icons/rolls.png";
import sideMan from "./assets/images/sideman.jpg";
import tabletsImage from "./assets/icons/tablets.png";
import twitterImage from "./assets/icons/twitter.png";
import videoChat from "./assets/images/videochat.png";
import videoImage from "./assets/images/video.png";
import youtubeImage from "./assets/icons/youtube.png";

export {
  arrowIcon,
  avatarGroup,
  appleLogo,
  checkImage,
  cnkavLogo,
  crowdImage,
  drinkMan,
  dropDownIcon,
  fiverStars,
  facebookLogo,
  galleryImage,
  gentalMan,
  greenCheck,
  googleLogo,
  helloHand,
  linkedinImage,
  modalMan,
  monyImage,
  nextIcons,
  questImage,
  rollsImage,
  sideMan,
  tabletsImage,
  twitterImage,
  videoChat,
  videoImage,
  youtubeImage,
};
