import drop from './assets/images/drop.png';
import video from './assets/images/video.png';
import Image1 from './assets/images/1.jpg';
import Image2 from './assets/images/2.jpg';
import Image3 from './assets/images/3.jpg';
import Image4 from './assets/images/4.jpg';
import questImage from './assets/images/quest.png'
import videochat from './assets/images/videochat.png'
import fram1Image from './assets/images/fram1.png';
import monyImage from './assets/images/mony.png';
import fram2Image from './assets/images/fram2.png';
import LogoImage from './assets/images/logo.png';
import galleryImage from './assets/images/gallery.png';
import arrowImage from './assets/images/arrow.png';
import greencheck from './assets/icons/green-check.png'
import ThreeD1 from './assets/icons/3d-1.png'
import ThreeD2 from './assets/icons/3d-2.png'
import checkImage from './assets/icons/check.png'

export {videochat,questImage,checkImage,ThreeD1,ThreeD2,greencheck,galleryImage,arrowImage,LogoImage,drop, video, Image1, Image2, Image3, Image4 ,fram1Image,monyImage,fram2Image};
